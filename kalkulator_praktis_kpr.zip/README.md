Kalkulator KPR — Kalkulator Praktis

Paket ini berisi aplikasi web KPR (PWA) siap deploy.
Upload semua file ke root repository GitHub dan aktifkan Pages, atau deploy ke Netlify/Vercel.